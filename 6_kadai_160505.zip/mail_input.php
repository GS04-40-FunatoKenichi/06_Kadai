<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<title>メール送信</title>
</head>
<body>
	
<form method="post" action="mail_send.php">
<p>お名前:<input type="text" name="name" size="20"></p>
<p>MAIL:<input type="text" name="mail" size="20"></p>
<p>問合せ:<input type="text" name="qa" size="20"></p>
<p><input type="submit" value="送信"></p>
</form>

</body>
</html>